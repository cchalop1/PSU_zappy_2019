/*
** EPITECH PROJECT, 2019
** Graphic_client
** File description:
** Enum_Zappy_Client.hpp
*/

#ifndef ENUM_ZAPPY_GRAPHIC_HPP_
#define ENUM_ZAPPY_GRAPHIC_HPP_

enum ITEM {
    FOOD = 0,
    LINEMATE = 1,
    DERAUMERE = 2,
    SIBUR = 3,
    MENDIANE = 4,
    PHIRAS = 5,
    THYSTAME = 6
};

enum ZAPPY {
    MAP = 0,
    PLAYER
};

#endif /* !ENUM_ZAPPY_GRAPHIC_HPP_ */